"""Factory-default onboarding. No existing household keys or TV addresses are used."""
import argparse
import base64
import contextlib
import hashlib
import http.cookiejar
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import importlib.util
import ipaddress
import json
import os
import platform
import re
from pathlib import Path
import secrets
import shlex
import shutil
import socket
import subprocess
import sys
import threading
import time
import tarfile
import zipfile
import urllib.parse
import urllib.request
import webbrowser

import setup as core

ROOT = Path(__file__).resolve().parents[1]
SERVER = 'https://family-tv-households.adoredhotel2.chatgpt.site'
SLOPBRO = ROOT / 'installer/slopbro/slopbro.py'
HELPER_STATUSES = {
    'pairing': 'Waiting for approval on the TV. Accept the pairing prompt if it appears.',
    'paired': 'TV pairing confirmed. Preparing SlopBro.',
    'launching': 'Opening SlopBro on the TV.',
    'serving': 'Waiting for the TV to download the setup files from this laptop.',
    'delivered': 'The TV downloaded the setup files. Checking for root access; returning to the home screen alone does not confirm success.',
    'failed': 'The setup helper reported an error. Checking whether root access was established before it stopped.'
}


def helper_status(message):
    """Translate upstream output into fixed messages; never forward keys or URLs."""
    for prefix, code in (('accept the pairing prompt', 'pairing'), ('registered', 'paired'),
                         ('launching ', 'launching'), ('waiting for all tracked', 'serving'),
                         ('done; all tracked', 'delivered'), ('error:', 'failed')):
        if message.startswith(prefix): return code
    return None


def private_ip(value):
    ip = ipaddress.IPv4Address(value)
    if not any(ip in ipaddress.ip_network(n) for n in ('10.0.0.0/8','172.16.0.0/12','192.168.0.0/16')):
        raise ValueError('Use the TV address on your home Wi-Fi.')
    return str(ip)


def local_ip(host):
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
        s.connect((private_ip(host), 9))
        return s.getsockname()[0]


def slopbro():
    path = SLOPBRO if SLOPBRO.exists() else ROOT/'vendor/slopbro/slopbro.py'
    spec = importlib.util.spec_from_file_location('family_slopbro', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def paired_lg(host, folder):
    m = slopbro()
    m.key_path = lambda ip: str(folder/'lg-pairing.key')
    try:
        ws = m.WebSocket.connect(host, 3001, secure=True)
    except (OSError, m.WebSocketError):
        ws = m.WebSocket.connect(host, 3000, secure=False)
    client = m.SSAPClient(ws)
    key = client.register(m.load_client_key(host), m.DEFAULT_MANIFEST)
    if key:
        m.save_client_key(host, key)
        with contextlib.suppress(OSError): os.chmod(folder/'lg-pairing.key', 0o600)
    return client


def lg_identity(client):
    unavailable=[]
    def query(uri):
        response = client.request(uri, {}, timeout=12)
        payload=response.get('payload')
        if response.get('type') == 'error' or not isinstance(payload,dict) or payload.get('returnValue') is False:
            unavailable.append(uri.rsplit('/',1)[-1]);return {}
        return payload
    system = query('ssap://system/getSystemInfo')
    sw = query('ssap://com.webos.service.update/getCurrentSWInformation')
    # Firmware major/minor is NOT the webOS SDK version.
    firmware = '.'.join(str(sw[k]) for k in ('major_ver','minor_ver') if sw.get(k) is not None)
    model = system.get('modelName') or sw.get('model_name')
    # Registration already succeeded. Firmware metadata is separately privileged
    # on LG: its denial must not masquerade as a pairing failure or root verdict.
    incomplete=not model or not firmware
    return {'brand':'lg','model':model or 'Paired LG TV','firmware':firmware or 'Not exposed by the TV',
            'paired':True,'metadataComplete':not incomplete,'unavailable':unavailable,'sdk':system.get('sdkVersion'),
            'identity':sw.get('device_id') or system.get('deviceId'),
            'compatibility':('Pairing succeeded. Some TV details are restricted; compatibility is still unverified. The no-USB attempt will check root access.' if incomplete else 'Root attempt available; exact firmware support will be verified on this TV.')}


def rooted_lg_identity(tv, identity):
    """Retrieve metadata via the local privileged API, only after root is proven."""
    raw=tv.ssh("luna-send -n 1 -w 5000 luna://com.webos.service.tv.systemproperty/getSystemInfo '{\"keys\":[\"modelName\",\"firmwareVersion\",\"sdkVersion\"]}'")
    info=json.loads(raw)
    if info.get('returnValue') is False:raise RuntimeError('The rooted TV could not confirm its system information.')
    result=dict(identity)
    for source,target in (('modelName','model'),('firmwareVersion','firmware'),('sdkVersion','sdk')):
        if isinstance(info.get(source),str) and info[source].strip():result[target]=info[source].strip()
    if result.get('model')=='Paired LG TV' or result.get('firmware')=='Not exposed by the TV':
        raise RuntimeError('Pairing and root succeeded, but system details are still unavailable. Family TV installation has stopped before replacing any TV files.')
    result.update(metadataComplete=True,compatibility='Root access verified on this TV.')
    return result


def http_json(url, data=None, opener=None, timeout=12):
    request=urllib.request.Request(url, data=None if data is None else json.dumps(data).encode(),
        headers={'Content-Type':'application/json'})
    with (opener or urllib.request.build_opener(core.NoRedirect)).open(request,timeout=timeout) as response:
        raw=response.read(2100000)
        if len(raw)>2000000: raise ValueError('TV response too large')
        return json.loads(raw)


def telnet_command(host, command, timeout=20):
    marker='FAMILY_'+secrets.token_hex(12)
    with socket.create_connection((host,23),timeout=5) as sock:
        sock.settimeout(1)
        with contextlib.suppress(socket.timeout): sock.recv(4096)
        # Echoed command cannot contain the complete completion marker.
        split=len(marker)//2
        script=command+"; printf '\\n%s%s:%s\\n' "+shlex.quote(marker[:split])+' '+shlex.quote(marker[split:])+ ' "$?"\n'
        sock.sendall(script.encode())
        data=b'';end=time.monotonic()+timeout
        while time.monotonic()<end:
            try: part=sock.recv(8192)
            except socket.timeout: continue
            if not part: break
            data+=part
            if len(data)>100000: raise RuntimeError('Unexpected root response')
            if (marker+':').encode() in data:
                result=data.decode(errors='replace')
                if marker+':0' not in result: raise RuntimeError('TV preparation did not complete')
                return result
    raise RuntimeError('The TV did not confirm root access within the time limit.')


def retain_host_identity(tv):
    """A DHCP move may add an address only for a previously recorded SSH key."""
    known=Path(tv.known).read_text()
    trusted={tuple(line.split()[1:3]) for line in known.splitlines() if len(line.split())>=3 and not line.startswith('#')}
    if not trusted:return
    scan=subprocess.run(['ssh-keyscan','-T','5','-t','ed25519,rsa',tv.host],capture_output=True,timeout=12)
    additions=[]
    for line in scan.stdout.decode(errors='replace').splitlines():
        fields=line.split()
        if len(fields)==3 and tuple(fields[1:]) in trusted:additions.append(line)
    if not additions:raise RuntimeError('This TV’s SSH identity does not match the saved installation. No credentials were transferred.')
    with Path(tv.known).open('a') as stream:stream.write('\n'+'\n'.join(additions)+'\n')


def lg_tv_binding(tv_command, binding, allow_sync=False):
    """Inspect occupied TV paths without returning or copying household secrets."""
    valid=bool(binding and re.fullmatch(r'[0-9a-f]{64}',binding))
    marker='/var/lib/tvweb/factory-owner'
    command=('if test -e /var/lib/tvweb; then echo base-present; else echo base-absent; fi; '
             'if test -f '+marker+'; then '
             'if test "$(cat '+marker+')" = '+shlex.quote(binding if valid else 'unbound')+'; '
             'then echo marker-matches; else echo marker-differs; fi; else echo marker-absent; fi; '
             'if test -f /var/lib/tvweb/tvwebctl; then echo control-present; else echo control-absent; fi; '
             'if test -f /var/lib/tvweb/family-base-upstream; then echo upstream-present; else echo upstream-absent; fi; '
             'if test -e /var/lib/family-sync; then echo sync-present; else echo sync-absent; fi')
    lines=tv_command(command).splitlines()
    if 'base-present' in lines:
        if 'marker-absent' in lines: raise RuntimeError('TV server folder exists without an ownership marker. This is likely an interrupted install; no files were overwritten. Diagnostics: '+', '.join(x for x in lines if x in ('control-present','control-absent','upstream-present','upstream-absent','sync-present','sync-absent')))
        if 'marker-differs' in lines: raise RuntimeError('TV server ownership marker does not match this laptop’s saved installation. No files were overwritten.')
        if 'marker-matches' not in lines: raise RuntimeError('Could not verify the TV server ownership marker. No files were overwritten.')
    if 'sync-present' in lines and not allow_sync:
        raise RuntimeError('TV sync files already exist without a matching saved enrollment. The installer will not transfer another home’s controls.')
    return 'owned' if 'base-present' in lines else 'fresh'


def matching_local_home(tv_command, root):
    """Compare TV ownership to local records on the TV; never return the marker."""
    entries=[]
    for path in Path(root).glob('home-*/tv-*/base-binding.json'):
        with contextlib.suppress(OSError,ValueError,KeyError):
            marker=core.read(path)['id']
            if re.fullmatch(r'[0-9a-f]{64}',marker):entries.append((path.parents[1],marker))
    if not entries:return None
    command='if test -f /var/lib/tvweb/factory-owner; then marker=$(cat /var/lib/tvweb/factory-owner); '
    for index,(_,value) in enumerate(entries):
        command+='if test "$marker" = '+shlex.quote(value)+'; then echo FAMILY_MATCH_'+str(index)+'; fi; '
    command+='fi'
    lines=tv_command(command).splitlines()
    for index,(home,_) in enumerate(entries):
        if 'FAMILY_MATCH_'+str(index) in lines:
            with contextlib.suppress(OSError,ValueError,KeyError):
                name=core.read(home/'name.json')['name']
                return name+' ['+home.name[-6:]+']'
    return None


class Onboarding:
    def __init__(self, folder):
        self.root=Path(folder).resolve();self.root.mkdir(parents=True,exist_ok=True)
        self.folder=self.root
        with contextlib.suppress(OSError): os.chmod(self.folder,0o700)
        self.lock=threading.Lock();self.continued=threading.Event()
        homes=[]
        for file in self.root.glob('home-*/name.json'):
            with contextlib.suppress(OSError,ValueError):homes.append({'id':file.parent.name,'name':core.read(file)['name']})
        self.state={'stage':'household','message':'Create a separate home, or explicitly select an existing home.','busy':False,'homes':homes}
        self.job=None;self.answer='';self.tv=None

    def select_home(self, body):
        if self.state['busy']: raise ValueError('Wait for the current operation to finish.')
        selected=body.get('id')
        if selected:
            if selected not in [h['id'] for h in self.state['homes']]: raise ValueError('Unknown household')
            folder=self.root/selected;name=core.read(folder/'name.json')['name']
        else:
            name=body.get('name','').strip()
            if not name or len(name)>60: raise ValueError('Enter a home name, up to 60 characters.')
            folder=self.root/('home-'+secrets.token_hex(12));folder.mkdir(mode=0o700)
            core.save(folder/'name.json',{'name':name})
            self.state['homes'].append({'id':folder.name,'name':name})
        self.folder=folder;self.job=None
        self.update(stage='select',home=name,homeId=folder.name,identity=None,dashboard=None,
                    message='Selected home: '+name+'. Add the TVs belonging to this home.')

    def update(self, **values):
        with self.lock:
            message=values.get('message')
            if message and message!=self.state.get('message'):
                history=self.state.setdefault('history',[])
                history.append({'at':time.time(),'message':message})
                del history[:-40]
            self.state.update(values)

    def progress(self, step, message):
        self.update(step=step,message=message,waitStarted=None,waitLimit=None)

    def read_helper(self, process, active):
        for line in process.stdout:
            if not active.is_set(): break
            if line.startswith('FAMILY_STATUS:'):
                code=line.strip().split(':',1)[1]
                if code in HELPER_STATUSES:
                    self.update(message=HELPER_STATUSES[code])

    def wait_user(self, message, field=False):
        self.continued.clear();self.update(message=message,needsContinue=True,needsInput=field)
        if not self.continued.wait(1800): raise RuntimeError('Setup paused. Keep this window open and start again when ready.')
        self.update(needsContinue=False,needsInput=False)
        return self.answer.strip()

    def launch(self, function):
        with self.lock:
            if self.state['busy']: raise ValueError('An operation is already running.')
            self.state.update(busy=True,error=None,startedAt=time.time(),finishedAt=None)
        def work():
            try: function()
            except Exception as e:
                message=('Select the TV found on your Wi-Fi, or enter its IP address.' if isinstance(e,ValueError) and str(e)=='Address cannot be empty' else 'Setup stopped. Your saved progress is kept on this laptop.')
                self.update(error=str(e),message=message,needsContinue=False)
            finally: self.update(busy=False,finishedAt=time.time())
        threading.Thread(target=work,daemon=True).start()

    def inspect(self, host, brand, label):
        self.job=None
        self.update(stage='identify',identity=None,dashboard=None)
        if not self.state.get('homeId'): raise ValueError('Choose or create a household first.')
        if not host.strip(): raise ValueError('Address cannot be empty')
        host=private_ip(host)
        if brand not in ('lg','samsung'): raise ValueError('Choose LG or Samsung.')
        if not label or len(label)>60: raise ValueError('Enter a room name, up to 60 characters.')
        folder=self.folder/('tv-'+host.replace('.','-'));folder.mkdir(exist_ok=True)
        # The folder's prior enrollment is never trusted based on IP alone.
        prior_identity=core.read(folder/'identity.json') if (folder/'identity.json').exists() else None
        self.update(stage='identify',message='Identifying your TV. Approve any pairing prompt on its screen.')
        if brand=='lg':
            client=paired_lg(host,folder)
            try: identity=lg_identity(client)
            finally: client.close()
        else:
            info=http_json('http://'+host+':8001/api/v2/')['device']
            if not info.get('id') or not info.get('modelName'): raise RuntimeError('Samsung did not return a stable device identity.')
            identity={'brand':'samsung','model':info['modelName'],'firmware':info.get('firmwareVersion','Not exposed by this model'),
                'identity':info['id'],'compatibility':'Vetro will verify root after installation. Frame model and firmware support varies.'}
        self.job={'host':host,'brand':brand,'label':label,'folder':str(folder),'identity':identity}
        if prior_identity and prior_identity.get('identity') and identity.get('identity')!=prior_identity['identity']:
            raise RuntimeError('This address now belongs to a different TV. The previous TV credentials will not be reused.')
        # Find a previously enrolled TV after DHCP rotation by authenticated SSAP
        # identity (or Samsung's stable ID), retaining its original credentials.
        if identity.get('identity'):
            for previous in self.folder.glob('tv-*/identity.json'):
                if core.read(previous).get('identity')==identity['identity'] and previous.parent!=folder:
                    self.job['folder']=str(previous.parent);break
        saved=Path(self.job['folder'])/'identity.json'
        if not saved.exists():core.save(saved,identity)
        self.update(stage='review',identity=identity,host=host,localIP=local_ip(host),
                    message='Review this TV, then choose Install. Setup changes only this selected TV.')

    def owner(self):
        path=self.folder/'household.json'
        if not path.exists(): core.save(path,{'server':SERVER,'token':secrets.token_hex(32)})
        owner=core.read(path)
        core.api(owner,'/api/households',{'name':self.state['home']})
        return owner

    def discover(self):
        self.update(message='Looking for TVs on your Wi-Fi…')
        # UDP routing selects the active LAN; discovery never scans the internet.
        interfaces={a[4][0] for a in socket.getaddrinfo(socket.gethostname(),None,socket.AF_INET)}
        candidates={}
        for interface in interfaces:
            try: private_ip(interface)
            except ValueError: continue
            for item in core.discover(interface):
                hint=(item.get('server','')+' '+item.get('identityHint','')).lower()
                brand='lg' if 'lg' in hint or 'webos' in hint else 'samsung' if 'samsung' in hint else None
                if not brand: continue
                host=private_ip(item['host']);root=False
                try:
                    with socket.create_connection((host,22 if brand=='lg' else 8099),timeout=.4):root=True
                except OSError: pass
                candidates[host]={'host':host,'brand':brand,'rootHint':root}
        self.update(candidates=list(candidates.values()),message='Select a TV below, or enter its IP address if discovery did not find it.')

    def install(self):
        if not self.job: raise ValueError('Identify a TV first.')
        job=self.job;folder=Path(job['folder']);host=job['host']
        self.update(stage='install',step=1,history=[],waitStarted=None,waitLimit=None,message='Preparing your separate household connection.')
        owner=self.owner()
        if job['brand']=='lg': self.install_lg(owner)
        else: self.install_samsung(owner)
        self.progress(5,'Checking that the TV is connected to your private dashboard…')
        end=time.monotonic()+100
        while time.monotonic()<end:
            devices=core.api(owner,'/api/devices')['devices']
            match=next((d for d in devices if d['id']==job['device']),None)
            if match and (match.get('snapshot') or {}).get('online') and time.time()*1000-match.get('received',0)<60000: break
            time.sleep(3)
        else: raise RuntimeError('TV installed, but the dashboard has not received a healthy connection. Setup has not been marked complete.')
        # Device must also acknowledge a command, not merely upload a snapshot.
        request_id=str(__import__('uuid').uuid4())
        self.progress(6,'TV connected. Sending a dashboard test command and waiting for its confirmation…')
        core.api(owner,'/api/devices/'+job['device']+'/commands',{'action':'refresh','requestId':request_id})
        end=time.monotonic()+100
        while time.monotonic()<end:
            rows=core.api(owner,'/api/devices/'+job['device']+'/commands')['results']
            found=next((r for r in rows if r['id']==request_id),{})
            if found.get('status')=='confirmed': break
            if found.get('status') in ('failed','uncertain','expired'): raise RuntimeError('The TV did not confirm the dashboard connection test.')
            time.sleep(3)
        else: raise RuntimeError('Waiting for a confirmed dashboard connection. Keep the TV awake and retry.')
        self.update(stage='complete',message='Root access, TV controls, and a dashboard command are verified. Open your private phone link below.',
                    dashboard=owner['server']+'/#'+owner['token'])

    def enroll(self, owner):
        folder=Path(self.job['folder']);path=folder/'enrollment.json'
        if (folder/'job.json').exists(): return core.read(folder/'job.json')
        result=core.api(owner,'/api/enrollments',{'label':self.job['label']})
        if path.exists(): path.rename(folder/('expired-enrollment-'+secrets.token_hex(4)+'.json'))
        core.save(path,{**result,'server':owner['server']})
        return result

    def install_lg(self, owner):
        job=self.job;host=job['host'];folder=Path(job['folder'])
        key=folder/'ssh_ed25519';known=folder/'known_hosts'
        binding_path=folder/'base-binding.json'
        binding=core.read(binding_path)['id'] if binding_path.exists() else None
        for program in ('ssh','ssh-keygen','ssh-keyscan'):
            if not shutil.which(program): raise RuntimeError('OpenSSH client is missing. Enable it in Windows Optional Features, then reopen setup.')
        if not key.exists():
            subprocess.run(['ssh-keygen','-t','ed25519','-N','','-f',str(key)],check=True,capture_output=True)
        known.touch(exist_ok=True)
        tv=core.TV(host,key,known)
        self.progress(2,'Checking for existing root access on this TV…')
        try: rooted=tv.ssh('id -u',timeout=12)=='0'
        except RuntimeError: rooted=False
        if not rooted and known.read_text().strip():
            retain_host_identity(tv)
            rooted=tv.ssh('id -u',timeout=12)=='0'
        if not rooted:
            self.update(message='Running the LG no-USB setup. Approve the TV prompt. If offered a reboot, choose Don’t reboot until setup finishes.',waitStarted=time.time(),waitLimit=240)
            process=subprocess.Popen([sys.executable,'-u',str(Path(__file__).resolve()),'--root-helper',host,'--state',str(folder)],
                cwd=str(folder),stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,text=True,encoding='utf-8',errors='replace')
            active=threading.Event();active.set()
            reader=threading.Thread(target=self.read_helper,args=(process,active),daemon=True);reader.start()
            root_seen=False
            try:
                end=time.monotonic()+240
                while time.monotonic()<end:
                    try:
                        result=telnet_command(host,'test "$(id -u)" = 0 && { if test -x /media/developer/apps/usr/palm/services/org.webosbrew.hbchannel.service/bin/dropbear; then printf "FAMILY_HBC_%s\\n" READY; else printf "FAMILY_HBC_%s\\n" WAIT; fi; }',5)
                        if not root_seen:
                            root_seen=True
                            self.update(message='Root shell confirmed. Waiting for Homebrew Channel to finish installing…')
                        if 'FAMILY_HBC_READY' in result: break
                        time.sleep(2)
                    except (OSError,RuntimeError): time.sleep(2)
                else:
                    if root_seen: raise RuntimeError('Root shell worked, but Homebrew Channel did not finish preparing its SSH service within four minutes. Family TV controls were not installed. This is not a firmware compatibility verdict.')
                    raise RuntimeError('No root shell was confirmed within four minutes. SlopBro launching or returning to the home screen does not confirm root. This can be a launch, connection, or firmware compatibility problem; Family TV controls were not installed.')
                active.clear();reader.join(timeout=1)
                self.progress(3,'Root access confirmed. Securing the private connection to this TV…')
                remote=lambda command:telnet_command(host,command,8)
                try: lg_tv_binding(remote,binding,(folder/'job.json').exists())
                except RuntimeError as error:
                    match=matching_local_home(remote,self.root) if 'does not match' in str(error) else None
                    detail=(' The matching saved home is '+match+'. Select it explicitly in the household menu.' if match else ' No saved home on this laptop matched the TV marker.' if 'does not match' in str(error) else '')
                    raise RuntimeError('Root works, but setup cannot safely resume: '+str(error)+detail) from error
                pub=key.with_suffix('.pub').read_text().strip()
                cmd='umask 077 && mkdir -p /home/root/.ssh /var/lib/webosbrew/sshd && touch /home/root/.ssh/authorized_keys && '
                cmd+='(grep -Fqx '+shlex.quote(pub)+' /home/root/.ssh/authorized_keys || printf "%s\\n" '+shlex.quote(pub)+' >> /home/root/.ssh/authorized_keys) && '
                cmd+='chmod 700 /home/root/.ssh && chmod 600 /home/root/.ssh/authorized_keys && touch /var/luna/preferences/webosbrew_sshd_enabled && '
                cmd+='(pidof dropbear >/dev/null || /media/developer/apps/usr/palm/services/org.webosbrew.hbchannel.service/bin/dropbear -R)'
                telnet_command(host,cmd)
                # Trust-on-first-use is limited to the selected, newly rooted TV;
                # every subsequent connection uses the recorded host key strictly.
                options=[v if v!='StrictHostKeyChecking=yes' else 'StrictHostKeyChecking=accept-new' for v in tv.options]
                r=subprocess.run(['ssh',*options,'root@'+host,'id -u'],capture_output=True,timeout=15)
                if r.returncode or r.stdout.strip()!=b'0': raise RuntimeError('Root was obtained, but the private SSH connection was not confirmed.')
                tv.ssh('killall telnetd 2>/dev/null || true')
            finally:
                active.clear()
                # SlopBro's temporary unauthenticated listener must not remain
                # open if a later installation step fails.
                with contextlib.suppress(OSError,RuntimeError):
                    telnet_command(host,'(sleep 1; killall telnetd 2>/dev/null) >/dev/null 2>&1 &',3)
                if process.poll() is None: process.terminate()
                process.wait(timeout=10)
                reader.join(timeout=2)
                process.stdout.close()
        self.tv=tv
        self.progress(3,'Private connection ready. Reading model and firmware directly from the TV…')
        job['identity']=rooted_lg_identity(tv,job['identity'])
        self.update(identity=job['identity'])
        self.progress(4,'Root verified. Installing the TV server and parental controls…')
        args=argparse.Namespace(host=host,key=str(key),known_hosts=str(known),vendor=str(ROOT/'vendor/glasshouse'))
        if not binding_path.exists():core.save(binding_path,{'id':secrets.token_hex(32)})
        args.installation_id=core.read(binding_path)['id']
        resume=(folder/'job.json').exists()
        if not resume:
            state=tv.ssh('if test -e /var/lib/family-sync; then echo occupied; elif test -f /var/lib/tvweb/factory-owner; then cat /var/lib/tvweb/factory-owner; elif test -e /var/lib/tvweb; then echo occupied; else echo fresh; fi')
            if state not in ('fresh',args.installation_id): raise RuntimeError('This TV already has an installation. It will not be taken over or linked to a different home.')
            if state=='fresh':core.install_base(args)
        self.progress(4,'TV server ready. Linking this TV to the selected household and installing dashboard sync…')
        enrollment=self.enroll(owner);job['device']=enrollment['device']
        args.job=str(folder/'job.json');args.enrollment=str(folder/'enrollment.json');args.resume=resume
        args.release=str(ROOT/'sites/family-tv/lib/tv-release.json');args.upstream_verified=core.UPSTREAM
        core.provision(args)

    def install_samsung(self, owner):
        job=self.job;host=job['host'];folder=Path(job['folder']);base='http://'+host+':8099'
        opener=urllib.request.build_opener(core.NoRedirect,urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
        authfile=folder/'samsung-auth.json'
        def call(route,body=None):
            if authfile.exists(): opener.addheaders=[('Authorization','Bearer '+core.read(authfile)['token'])]
            return http_json(base+route,body,opener,45)
        try: status=call('/status')
        except urllib.error.HTTPError as error:
            status={} if error.code in (401,403) else None
        except (OSError,ValueError): status=None
        if status is None:
            cli=self.samsung_cli()
            self.wait_user('On the Samsung TV: open Apps, enter 12345 using the remote, turn Developer Mode on, and set Host PC IP to '+local_ip(host)+'. Restart the TV, then click Continue.')
            self.update(message='Installing Vetro. Check the launcher terminal and Samsung sign-in window; sign in there if requested.')
            # Interactive certificate sign-in belongs to Samsung/Apps2Samsung.
            # No passwords are captured by the wizard.
            result=subprocess.run([str(cli),'install','Vetro','--tv',host,'--allow-root'],cwd=folder,timeout=1800)
            if result.returncode: raise RuntimeError('Samsung installer did not finish. Its terminal shows the specific sign-in or TV connection step.')
            self.wait_user('Open Vetro on the TV once. Then open Apps → 12345 again, set Host PC IP to 127.0.0.1, and restart the TV. Click Continue after it has restarted.')
        self.update(message='Waiting for Samsung’s root service to start…')
        deadline=time.monotonic()+180
        while time.monotonic()<deadline:
            try:
                status=call('/status')
                if status.get('agent',{}).get('connected') and status['agent'].get('uid')==0: break
            except urllib.error.HTTPError as error:
                if error.code in (401,403):
                    pairing=call('/auth/pair',{'name':'Family TV setup'})
                    code=self.wait_user('Enter the six-digit pairing code displayed by Vetro on your TV.',True)
                    auth=call('/auth/confirm',{'id':pairing['id'],'code':code})
                    if not auth.get('token'): raise RuntimeError('TV pairing was not confirmed.')
                    if authfile.exists(): authfile.unlink()
                    core.save(authfile,{'token':auth['token']});deadline=time.monotonic()+180
                else: raise
            except (OSError,ValueError): pass
            time.sleep(3)
        else: raise RuntimeError('Samsung root was not confirmed. This firmware may be unsupported, or Host PC IP is not 127.0.0.1. The dashboard has not been marked ready.')
        current=http_json('http://'+host+':8001/api/v2/')['device']
        if current.get('id')!=job['identity']['identity']: raise RuntimeError('The selected Samsung TV identity changed. Stopping.')
        resume=(folder/'job.json').exists()
        marker=call('/exec',{'cmd':'if test -f /opt/usr/home/owner/share/family-tv-household; then cat /opt/usr/home/owner/share/family-tv-household; else echo absent; fi'})
        binding=marker.get('output','').strip()
        if binding!='absent' and (not resume or binding!=core.read(folder/'job.json')['device']):
            raise RuntimeError('This Samsung is already linked to a household. Explicit transfer is required.')
        plugins=call('/plugins').get('plugins',[])
        if not resume and any(p.get('id')=='family-tv' for p in plugins): raise RuntimeError('This Samsung already has Family TV. It will not be overwritten by a new household.')
        enrollment=self.enroll(owner)
        if resume:
            credential=core.read(folder/'job.json');core.api(credential,'/api/device/identity')
        else:
            credential={'server':owner['server'],'token':secrets.token_hex(32),'device':enrollment['device'],'household':enrollment['household']}
            core.save(folder/'job.json',credential)
            core.api({**enrollment,'server':owner['server']},'/api/enroll/claim',{'deviceToken':credential['token']})
        job['device']=credential['device']
        release=core.read(ROOT/'sites/family-tv/lib/samsung-release.json')
        encoded=json.dumps(release['bundle'],ensure_ascii=False,separators=(',',':')).encode()
        if hashlib.sha256(encoded).hexdigest()!=release['sha256']: raise ValueError('Samsung package integrity check failed.')
        bundle=release['bundle'];source=bundle['files']['index.js']
        self.update(message='Checking which installed Samsung apps support native PIN protection…')
        # Discover this TV's actual apps; never install another family's app list.
        raw_apps=call('/apps').get('apps',[])
        runtime=base64.b64encode(bundle['files']['AppLock.runtimeconfig.json'].encode()).decode()
        call('/exec',{'cmd':'umask 077; printf "%s" '+shlex.quote(bundle['files']['AppLock.base64'])+' | base64 -d > /tmp/family-tv-lock-probe.dll; printf "%s" '+shlex.quote(runtime)+' | base64 -d > /tmp/family-tv-lock-probe.runtimeconfig.json'})
        apps=[];locked=[]
        for app in raw_apps[:300]:
            app_id=app.get('appId','')
            if not app.get('show') or app.get('disabled') or app.get('launchRisk') or not re.fullmatch(r'[A-Za-z0-9._-]{1,120}',app_id):continue
            probe=call('/exec',{'cmd':'/usr/bin/dotnet /tmp/family-tv-lock-probe.dll '+shlex.quote(app_id)})
            if not probe.get('ok') or probe.get('exit_code',0)!=0:continue
            try:info=json.loads(probe.get('output',''))['app_info'][0]
            except (ValueError,KeyError,IndexError):continue
            apps.append({'id':app_id,'name':str(app.get('name') or app_id)[:100]})
            if str(info.get('is_lock'))=='1':locked.append(app_id)
        if not apps:raise RuntimeError('Root works, but no apps confirmed support for native PIN protection. Family TV is not marked ready.')
        start=source.index('var APPS = [');end=source.index('\n];',start)+3
        source=source[:start]+'var APPS = '+json.dumps(apps)+';'+source[end:]
        source=source.replace('state.protectedApps = APPS.map(function (app) { return app.id; });','state.protectedApps = '+json.dumps(locked)+';')
        anchor='    return {\n        start: function () {'
        if source.count(anchor)!=1: raise ValueError('Samsung plugin integration changed.')
        injected=(ROOT/'installer/samsung-cloud.js').read_text().replace('FAMILY_CLOUD_CONFIG',json.dumps({**credential,'model':job['identity']['model']}))
        source=source.replace(anchor,injected+'\n'+anchor)
        source=source.replace('            running = true;','            running = true; familyCloudTimer=setInterval(familyCloudCycle,10000);')
        source=source.replace('stop: function () { running = false;','stop: function () { clearInterval(familyCloudTimer); running = false;')
        bundle['files']['index.js']=source
        call('/plugins/developer',{'on':True})
        if not call('/plugins/install',bundle).get('ok'): raise RuntimeError('Samsung rejected the Family TV adapter.')
        if not call('/plugins/family-tv/enable',{}).get('ok'): raise RuntimeError('Samsung could not start the Family TV adapter.')
        marker=call('/exec',{'cmd':'umask 077; printf "%s" '+shlex.quote(credential['device'])+' > /opt/usr/home/owner/share/family-tv-household'})
        if not marker.get('ok') or marker.get('exit_code',0)!=0: raise RuntimeError('Samsung did not save its household binding.')

    def samsung_cli(self):
        system={'Windows':'win','Darwin':'osx','Linux':'linux'}.get(platform.system())
        arch='arm64' if platform.machine().lower() in ('arm64','aarch64') else 'x64'
        variant=system+'-'+arch if system else ''
        hashes={'win-x64':'286fc1fcd3c82a3f39a0cff90c5699818300add981bbc44b77e2d1a04289b351',
          'win-arm64':'e65374d6982d42c78c9fd2e06fe117e09c20b3c40b18b67c6ba2b81148368911',
          'osx-arm64':'f3a63efb340a66791108ca7ff5f968cbd28c24608c0b891f73fa853ab34d3a81',
          'osx-x64':'80fb2a81a7ea8b6e577582aaf2cbaee82e8719dc8dd2ffa88cb679ddf45b5c8d',
          'linux-x64':'385cffe090e76ae956160fc20bef339608e7564dd404e793b4f95616ae448375',
          'linux-arm64':'377de9d64156d1fed7ed71327983db5d2932710f3d28121d01360eef0474702b'}
        if variant not in hashes: raise RuntimeError('This computer platform is not supported by the Samsung installer.')
        folder=self.folder/'tools'/variant;folder.mkdir(parents=True,exist_ok=True)
        archive=folder/('cli.zip' if system=='win' else 'cli.tar.gz')
        name='Apps2Samsung.Cli-v3.3.1-'+variant+('.zip' if system=='win' else '.tar.gz')
        if not archive.exists():
            self.update(message='Downloading the verified Samsung installer…')
            with urllib.request.urlopen('https://github.com/Apps2Samsung/Apps2Samsung/releases/download/v3.3.1/'+name,timeout=60) as response:
                with archive.open('wb') as out:
                    total=0
                    while True:
                        chunk=response.read(1024*1024)
                        if not chunk: break
                        total+=len(chunk)
                        if total>150000000: raise ValueError('Samsung download exceeds expected size')
                        out.write(chunk)
        if hashlib.sha256(archive.read_bytes()).hexdigest()!=hashes[variant]:
            archive.unlink();raise RuntimeError('Samsung download integrity check failed. Retry to download a fresh copy.')
        if system=='win':
            with zipfile.ZipFile(archive) as z:
                for entry in z.infolist():
                    if Path(entry.filename).name=='apps2samsung-cli.exe':
                        binary=folder/'apps2samsung-cli.exe';binary.write_bytes(z.read(entry));return binary
        else:
            with tarfile.open(archive) as tar:
                for entry in tar.getmembers():
                    if entry.isfile() and Path(entry.name).name=='apps2samsung-cli':
                        binary=folder/'apps2samsung-cli';binary.write_bytes(tar.extractfile(entry).read());binary.chmod(0o700);return binary
        raise RuntimeError('Samsung CLI executable was not found in the verified package.')


class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args): pass  # Never log access tokens or pairing codes.
    def send(self,status,data,kind='application/json'):
        raw=json.dumps(data).encode() if kind=='application/json' else data
        self.send_response(status);self.send_header('Content-Type',kind);self.send_header('Content-Length',str(len(raw)))
        self.send_header('Cache-Control','no-store');self.send_header('Referrer-Policy','no-referrer');self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(raw)
    def authorized(self):
        origin='http://127.0.0.1:'+str(self.server.server_port)
        return self.headers.get('Host')==origin[7:] and self.headers.get('Origin',origin)==origin and secrets.compare_digest(self.headers.get('Authorization',''),'Bearer '+self.server.capability)
    def do_GET(self):
        if self.headers.get('Host')!='127.0.0.1:'+str(self.server.server_port): return self.send(403,{'error':'Invalid host'})
        if self.path=='/': return self.send(200,(ROOT/'installer/factory.html').read_bytes(),'text/html; charset=utf-8')
        if self.path=='/qr.js':
            path=ROOT/'installer/qr.js'
            raw=path.read_bytes() if path.exists() else (ROOT/'services/households/qr.js').read_bytes()+b'\nfunction FamilyQR(value){var q=qrcode(0,"M");q.addData(value);q.make();return q.createSvgTag({cellSize:5,margin:4,scalable:true});}'
            return self.send(200,raw,'application/javascript')
        if self.path=='/api/state' and self.authorized():
            with self.server.flow.lock: return self.send(200,self.server.flow.state)
        return self.send(403,{'error':'Open setup from the launcher.'})
    def do_POST(self):
        if not self.authorized() or self.headers.get('Content-Type')!='application/json': return self.send(403,{'error':'Invalid local request'})
        try:
            size=int(self.headers.get('Content-Length','0'))
            if not 0<size<=4096: raise ValueError('Invalid request size')
            body=json.loads(self.rfile.read(size));flow=self.server.flow
            if self.path=='/api/household': flow.select_home(body)
            elif self.path=='/api/identify': flow.launch(lambda: flow.inspect(body.get('host',''),body.get('brand',''),body.get('label','')))
            elif self.path=='/api/discover': flow.launch(flow.discover)
            elif self.path=='/api/install': flow.launch(flow.install)
            elif self.path=='/api/continue':
                if not flow.state.get('needsContinue'): raise ValueError('No step is waiting')
                flow.answer=str(body.get('answer',''));flow.continued.set()
            else: return self.send(404,{'error':'Unknown step'})
            self.send(200,{'ok':True})
        except (ValueError,KeyError) as e: self.send(400,{'error':str(e)})


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--state',default=str(Path.home()/'.family-tv'))
    parser.add_argument('--root-helper');parser.add_argument('--no-browser',action='store_true');args=parser.parse_args()
    if args.root_helper:
        host=private_ip(args.root_helper);m=slopbro();m.key_path=lambda ip:str(Path(args.state)/'lg-pairing.key')
        def safe_log(message):
            code=helper_status(message)
            if code: print('FAMILY_STATUS:'+code,flush=True)
        m.log=safe_log
        original_connect=m.WebSocket.connect
        def connect(host,port,secure=False):
            try:return original_connect(host,port,secure=secure)
            except (OSError,m.WebSocketError):
                if secure:return original_connect(host,3000,secure=False)
                raise
        m.WebSocket.connect=connect
        original=m.build_self_hosted_url
        m.build_self_hosted_url=lambda *a,**kw:original(*a,**kw)+'&telnet'
        m.run(host,local_ip_override=local_ip(host));return
    server=ThreadingHTTPServer(('127.0.0.1',0),Handler);server.capability=secrets.token_hex(32)
    server.flow=Onboarding(args.state)
    url='http://127.0.0.1:'+str(server.server_port)+'/#'+server.capability
    print('Family TV setup is running. Keep this window open.\n'+url,flush=True)
    if not args.no_browser: webbrowser.open(url)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.server_close()


if __name__=='__main__': main()

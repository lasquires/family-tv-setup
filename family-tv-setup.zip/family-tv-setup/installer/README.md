# Household pilot setup

## Guided installation for a family

The preferred pilot path now uses a private setup kit and a guided launcher. The operator first provisions the cloud household and authorized TV access, then runs:

```powershell
python installer/setup.py make-kit --owner .local/other-family/owner.json --key .local/other-family/tv_ed25519 --known-hosts .local/other-family/known_hosts --out .local/other-family/setup-kit.json --upstream-verified 0a110e74a0c1256134a4ff93f351919023306d07
python installer/setup.py guided --kit .local/other-family/setup-kit.json
```

The family enters the TV IP, names the room and confirms the target. The guided path checks the cloud household, refuses an already enrolled TV, installs the base when absent, enrolls, bootstraps family files and completes authenticated sync. The compatibility assertion belongs to the operator, not the family. It is not automatic model certification.

`make-kit` references existing credential files without copying them. For another computer, the operator must place that household's credentials securely on that computer and update the kit's file paths (relative paths are resolved beside the kit). Never send your own home's credential files. On Windows run `installer/Start-Setup.ps1` or the direct Python command; on Mac/Linux use `bash installer/Start-Setup.command`.

Build a credential-free ZIP with `python scripts/build-setup-package.py`. The output `.local/family-tv-setup.zip` includes only explicit code/release files and a committed upstream archive. Families using the ZIP need Python 3 and OpenSSH, but not Git. The public setup wizard is in `setup/`; its publication workflow is prepared, not deployed.

This is the first implemented slice of the multi-household guide. It is a command-line pilot for a prepared LG TV with authorized root SSH and Homebrew Channel. Use a computer on the TV network. Nothing here migrates the existing private Site or its TV. Do not use that Site's database or credentials for this service.

Implemented: separate owner credentials, household-scoped device registry and queues, one-time enrollment, per-device tokens, revocation, bounded commands, discovery, fresh base install, initial Family TV bundle installation, resume and pending-update rollback. Ordinary LG pairing does not provide root access.

Not yet implemented: browser accounts/invitations, a multi-household dashboard, MCP OAuth, signed downloadable installers/releases, automated root preparation, Samsung TV provisioning, Android packaging, automatic update distribution, or a persistent wake relay. This pilot queues all commands for up to five minutes and marks uncertain delivery for manual review. It does not inherit the legacy service's durable retry/family-wide policy behavior.

## Set up the new server once

Code lives in the existing GitHub repository; runtime hosting is a separate Cloudflare Worker and D1 database. GitHub Pages cannot run the backend. Keep the old private Site deployed separately.

Run from the repository root with Node, Python 3, Git and OpenSSH installed. The current checkout's files must be committed and pushed before another computer can clone this version.

```powershell
git clone https://github.com/lasquires/family-tv.git
Set-Location family-tv
git clone https://github.com/rorygallagher2024/glasshouse.git vendor/glasshouse
git -C vendor/glasshouse checkout 0a110e74a0c1256134a4ff93f351919023306d07
```

Install project dependencies if absent (`npm run install:ci` from `sites/family-tv`). Use the bundled Wrangler from the repository root:

```powershell
node sites/family-tv/node_modules/wrangler/bin/wrangler.js login
node sites/family-tv/node_modules/wrangler/bin/wrangler.js d1 create family-tv-households-pilot
Copy-Item services/households/wrangler.example.json services/households/wrangler.local.json
```

Edit `services/households/wrangler.local.json`: replace the placeholder database ID with the NEW database ID returned above. This local configuration is ignored by Git. Never put the old Site database ID here.

```powershell
node sites/family-tv/node_modules/wrangler/bin/wrangler.js d1 migrations apply family-tv-households-pilot --remote --config services/households/wrangler.local.json
node sites/family-tv/node_modules/wrangler/bin/wrangler.js deploy --config services/households/wrangler.local.json
```

Record the HTTPS Worker origin printed by deployment. Each household uses this same origin. Keep access to operator credentials restricted. Before broader distribution, add account sign-in, credential rotation UI, API rate limiting, operational monitoring and a managed release channel. There is no browser landing page in this pilot.

## Create one household

Use a new output directory for each family. This generates a unique random owner credential locally and SQL containing only its hash. The name is just a label; it does not grant membership.

```powershell
python installer/setup.py create-household --name "Other family" --server https://YOUR-WORKER.workers.dev --out .local/other-family
node sites/family-tv/node_modules/wrangler/bin/wrangler.js d1 execute family-tv-households-pilot --remote --config services/households/wrangler.local.json --file .local/other-family/provision.sql
python installer/setup.py devices --owner .local/other-family/owner.json
```

The last command should show an empty device list. `owner.json` is a bearer credential with full pilot access to only that household. Keep it in a private folder, outside shared cloud folders if possible; never paste it into chat or Git. The `.local` path is ignored, not encrypted. On Windows, file protection relies on the containing directory's ACL. The installer uses mode 0600 on platforms that support POSIX permissions.

## At the other house

1. Join the same Wi-Fi as the TV. The TV must already have authorized root SSH and Homebrew Channel. Check model/firmware eligibility separately.
2. Find the TV IP in its network settings or discover candidates. In PowerShell, `Get-NetIPConfiguration` shows your computer's Wi-Fi address. Supply that computer address to discovery:

```powershell
python installer/setup.py discover --interface 192.168.1.20
```

Discovery does not pair or modify anything. SSDP responses are untrusted hints and some networks block them. Manual TV IP entry always works as a fallback.

3. Prepare a unique SSH key and verified known-hosts file through the authorized TV setup. Do not copy the current home's keys or credentials. Verify the TV host fingerprint before accepting a first connection. The installer deliberately refuses unknown or changed host keys.
4. If this TV has no Glasshouse installation, install the base from the pinned Git commit:

```powershell
python installer/setup.py install-base --host 192.168.1.50 --key .local/other-family/tv_ed25519 --known-hosts .local/other-family/known_hosts
```

This copies only committed upstream source, creates a unique TV-local API token and starts the TV server. It refuses any existing `/var/lib/tvweb` or `/var/lib/family-sync`. The HTTP listener is loopback-only. Base install does not automatically switch the TV home screen or install a launcher tile. Configure that separately after core controls are verified. If base installation is interrupted, inspect the TV before retrying; this command does not erase a partial installation.

For a TV with an existing base, verify it is compatible with the pinned upstream revision. Do not reinstall base over it. The family installer refuses an existing Family TV installation and cannot take over your current home.

```powershell
python installer/setup.py inspect --host 192.168.1.50 --key .local/other-family/tv_ed25519 --known-hosts .local/other-family/known_hosts
python installer/setup.py enroll --owner .local/other-family/owner.json --label "Living room" --out .local/other-family/enrollment.json
python installer/setup.py install --host 192.168.1.50 --key .local/other-family/tv_ed25519 --known-hosts .local/other-family/known_hosts --enrollment .local/other-family/enrollment.json --job .local/other-family/install-job.json --upstream-verified 0a110e74a0c1256134a4ff93f351919023306d07
```

Enrollment expires in ten minutes. Install validates the release's exact file allowlist and hashes, claims a device, invokes the TV's existing bounded bootstrap/rollback mechanism, completes an authenticated sync, then starts the boot-persistent supervisor. It sends credentials over SSH stdin, never command-line arguments. Source and release must come from your reviewed repository; hash checks do not replace release signatures.

The pinned revision flag records your compatibility check; it is not automatic hardware certification. Do not select it for an unverified model/firmware/base combination. Physical testing on a second TV is still required.

## Verify controls and isolation

```powershell
python installer/setup.py devices --owner .local/other-family/owner.json
```

Copy the device ID returned (not the TV IP). Save `{"action":"refresh"}` in `.local/other-family/refresh.json`, then run:

```powershell
python installer/setup.py command --owner .local/other-family/owner.json --device DEVICE-UUID --json .local/other-family/refresh.json
python installer/setup.py status --owner .local/other-family/owner.json --device DEVICE-UUID
```

Wait for `confirmed`; queued does not mean applied. Supported pilot actions are refresh, protectApp, passcodes, pausePins, sleepTimer, grant and revoke. There is no arbitrary shell tool or cross-household policy synchronization. Test a short timed grant, local expiry, cold boot and an Internet outage before handing over. Run `devices` with a second household owner file and verify it does not list this TV.

## IP changes and interrupted installs

Once installed, the TV connects outward with its device token and uses its own loopback API. DHCP address rotation does not change cloud identity or household ownership. A DHCP reservation is optional for maintenance. Discovery and manual IP selection are used only during setup/SSH maintenance; a new address must still pass host-key verification. Existing wake relays in the old project have separate address assumptions and are not part of this pilot.

After an interrupted claim/install, keep `install-job.json`: its persisted token allows resuming if the one-time claim succeeded but its response was lost. Verify the same physical TV/host key and use:

```powershell
python installer/setup.py install --resume --host 192.168.1.50 --key .local/other-family/tv_ed25519 --known-hosts .local/other-family/known_hosts --job .local/other-family/install-job.json --upstream-verified 0a110e74a0c1256134a4ff93f351919023306d07
```

Resume verifies the cloud identity and on-TV device marker. If the original claim never reached the server, identity verification fails; revoke/expire the enrollment and start with a new output file. A failure between directory creation and marker write needs operator inspection; the installer deliberately does not assume an unmarked directory is safe to overwrite. A release that failed health checks remains blocked until reviewed/corrected.

To stop sync and restore an interrupted file update:

```powershell
python installer/setup.py recover --host 192.168.1.50 --key .local/other-family/tv_ed25519 --known-hosts .local/other-family/known_hosts
python installer/setup.py revoke --owner .local/other-family/owner.json --device DEVICE-UUID
```

`recover` restores only a pending update; it is not an uninstall. Revocation stops future cloud access and cancels pending commands; existing local rules remain on the TV. Do not erase another family's PINs or configuration to resolve a networking issue.

## Verification and next steps

### GitHub Pages setup wizard

A future `github.io` page can be the public setup entry point, with downloads, instructions and a TV selection/IP form. GitHub Pages cannot execute SSH or run this Python installer itself. Pair it with a local companion process using the installer core.

For the first graphical release, prefer having the companion open its own loopback web UI. The GitHub page launches/downloads the helper and explains the flow; the local page handles discovery, selection, credentials and progress. This avoids making the public webpage a bridge to arbitrary LAN operations. Bind the helper only to loopback, require a per-launch capability token, validate Host and Origin on every request, prohibit arbitrary commands/paths and remote URLs, and expire access when setup ends. Do not expose an unauthenticated local HTTP API.

If the hosted page later talks directly to the companion, require explicit user pairing, exact origin allowlisting, short-lived authorization, local-network permission handling and tests for malicious websites, CSRF, DNS rebinding and redirects. Keep SSH keys and enrollment credentials out of browser storage. Never publish owner.json or a provisioning job in GitHub Pages assets. Android needs an equivalent native companion or the experimental terminal path; the website alone cannot provide SSH access.

The graphical wizard and local HTTP companion are planned, not included in this CLI pilot.

```powershell
node tests/household-isolation.test.mjs
python tests/installer.test.py
node tests/tv-sync.test.cjs
```

Tests use in-memory SQLite, local temporary files and mocked SSH. The base bundle test reads the pinned local vendor checkout. No test installs software on a real TV. Next release work: physical two-home pilot, user sign-in and invitations, phone dashboard, signed distribution, policy parity, then Android provisioning and MCP OAuth. See `docs/MULTI-HOUSEHOLD-IMPLEMENTATION.md` for the full plan.

'use strict';
// Installer-only activation of the unchanged GitHub home renderer and preset.
const fs=require('fs'),Sync=require('/var/lib/family-sync/tv-sync').Sync;
const marker='/var/lib/family-sync/home-configured.json';
async function configure(){
 if(fs.existsSync(marker))return;
 const sync=new Sync(),preset=JSON.parse(fs.readFileSync('/var/lib/family-sync/home-preset.json','utf8'));
 const layout=await sync.local('/api/home/layout',preset.layout);if(!layout.ok)throw Error('The TV rejected the standard home layout');
 try{const enabled=await sync.local('/api/home/enable',{});if(!enabled.ok)throw Error('Home enable rejected');}catch(e){
  // Activation can outlive the HTTP timeout on slower TVs; inspect before retrying.
  await sync.delay(2000);if(!(await sync.local('/api/home')).enabled)throw e;
 }
 const opened=await sync.local('/api/control',{action:'launch_app',value:'com.tvweb.home'});if(!opened.ok)throw Error('The TV did not open Family TV home');
 for(let n=0;n<10;n++){
  const state=await sync.local('/api/home');
  if(state.enabled&&state.active){fs.writeFileSync(marker,JSON.stringify({enabled:true,active:true}),{mode:384});console.log('Standard Family TV home is enabled and active.');return;}
  await sync.delay(1000);
 }
 throw Error('The TV did not confirm the home screen is active');
}
configure().catch(e=>{console.error(e.message);process.exitCode=1;});

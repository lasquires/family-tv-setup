#!/bin/bash
set -eu
cd "$(dirname "$0")/.."
printf '%s\n' 'Family TV guided setup' 'Your setup operator supplies a private setup-kit.json file for this home.'
if ! command -v python3 >/dev/null; then
  printf '%s\n' 'Python 3 is required. Ask your setup operator to install it first.'
  exit 1
fi
printf 'Full path to setup-kit.json: '
IFS= read -r kit
python3 installer/setup.py guided --kit "$kit"
printf 'Press Enter to close.'
IFS= read -r answer

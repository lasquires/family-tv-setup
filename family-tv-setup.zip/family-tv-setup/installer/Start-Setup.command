#!/bin/bash
set -eu
cd "$(dirname "$0")/.."
if ! command -v python3 >/dev/null; then
  printf '%s\n' 'Install Python from the official page that is opening, then run setup again.'
  if command -v open >/dev/null; then open 'https://www.python.org/downloads/macos/'; fi
  exit 1
fi
python3 installer/factory.py

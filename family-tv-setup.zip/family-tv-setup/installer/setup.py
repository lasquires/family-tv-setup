"""Family TV pilot operator CLI. Credentials live in local files, never arguments."""
import argparse
import hashlib
import ipaddress
import io
import json
import os
from pathlib import Path
import secrets
import socket
import tarfile
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid

ROOT = Path(__file__).resolve().parents[1]
UPSTREAM = '0a110e74a0c1256134a4ff93f351919023306d07'
ALLOW = {'lib/family.js', 'assets/family.html', 'lib/profiles.js', 'assets/profile-picker.js', 'lib/routes.js', 'assets/home.html'}


def preflight(host):
    address=ipaddress.IPv4Address(host)
    if not any(address in ipaddress.ip_network(n) for n in ('10.0.0.0/8','172.16.0.0/12','192.168.0.0/16')):
        raise ValueError('Enter the TV private IPv4 address from its network settings')
    results={}
    for port in (22,8080):
        try:
            with socket.create_connection((str(address),port),timeout=3):results[str(port)]='reachable'
        except OSError:results[str(port)]='not reachable'
    return {'tvAddress':str(address),'ports':results,'changedTV':False,
            'next':'Record the exact model, software version and whether Homebrew Channel is installed. An open port does not prove authorized access or compatibility.'}


def discover(interface, seconds=3):
    """SSDP discovery only. Results are untrusted candidates, not paired identities."""
    address = str(ipaddress.IPv4Address(interface))
    message = ('M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\n'
               'MAN: "ssdp:discover"\r\nMX: 2\r\nST: ssdp:all\r\n\r\n').encode()
    found = {}
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP) as sock:
        sock.bind((address, 0))
        sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_IF, socket.inet_aton(address))
        sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 2)
        sock.settimeout(0.3)
        sock.sendto(message, ('239.255.255.250', 1900))
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline and len(found) < 100:
            try: data, peer = sock.recvfrom(8192)
            except socket.timeout: continue
            fields = {}
            for line in data.decode('utf-8', errors='replace').splitlines()[1:]:
                if ':' in line:
                    k, v = line.split(':', 1); fields[k.lower()] = v.strip()[:300]
            found[(peer[0], fields.get('usn',''))] = {'host':peer[0], 'identityHint':fields.get('usn'), 'server':fields.get('server')}
    return list(found.values())


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    # Exclusive creation prevents accidentally replacing another home's credentials.
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'w', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2)


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def endpoint(url):
    parsed = urllib.parse.urlsplit(url)
    if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment or parsed.path not in ('', '/'):
        raise ValueError('Server must be an HTTPS origin without credentials or a path')
    return url.rstrip('/')


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        raise ValueError('Server redirect refused; verify the configured HTTPS origin')


def api(config, route, payload=None, token=None):
    req = urllib.request.Request(endpoint(config['server']) + route,
        data=None if payload is None else json.dumps(payload).encode(),
        headers={'Authorization': 'Bearer ' + (token or config['token']), 'Content-Type': 'application/json'})
    try:
        with urllib.request.build_opener(NoRedirect).open(req, timeout=30) as response:
            return json.loads(response.read(250000))
    except urllib.error.HTTPError as exc:
        raise RuntimeError('Server rejected request (HTTP %s)' % exc.code) from None


def release(path):
    value = read(path)
    if value.get('upstream') != UPSTREAM or len(value.get('files', [])) != len(ALLOW) or {f['path'] for f in value['files']} != ALLOW:
        raise ValueError('Release does not match the pinned LG adapter')
    for item in value['files']:
        data = item['content'].encode('utf-8')
        if len(data) > 1500000 or hashlib.sha256(data).hexdigest() != item['sha256']:
            raise ValueError('Release hash mismatch')
    return value


def base_bundle(vendor):
    """Read committed files only; never copy a developer's per-TV config or keys."""
    packaged=ROOT/'installer/upstream-server.tar'
    if packaged.is_file():
        raw=packaged.read_bytes()
        expected=(ROOT/'installer/upstream-server.sha256').read_text().strip()
        if hashlib.sha256(raw).hexdigest()!=expected:raise ValueError('Packaged upstream files failed integrity verification')
    else:
        raw = subprocess.run(['git','-C',str(vendor),'archive','--format=tar',UPSTREAM,'server'],capture_output=True,check=True).stdout
    output=io.BytesIO()
    with tarfile.open(fileobj=io.BytesIO(raw),mode='r:') as source, tarfile.open(fileobj=output,mode='w',format=tarfile.USTAR_FORMAT) as target:
        for item in source.getmembers():
            if not item.isfile() or not item.name.startswith('server/'): continue
            name=item.name[len('server/'):]
            parts=Path(name).parts
            if '..' in parts or name.startswith('/') or any(p.startswith('.') for p in parts): continue
            if name.startswith('config.') or name in ('config.json','deploy.sh'): continue
            stream=source.extractfile(item)
            item.name=name;item.uid=item.gid=0;item.uname=item.gname='root';item.mode=0o700 if item.mode & 0o111 else 0o600
            target.addfile(item,stream)
        config=json.dumps({'token':secrets.token_hex(32),'host':'127.0.0.1','port':8080,'update':{'check':False}}).encode()
        for name,data in [('config.json',config),('family-base-upstream',UPSTREAM.encode())]:
            item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o600;target.addfile(item,io.BytesIO(data))
    return output.getvalue()


def install_base(args):
    tv=TV(args.host,args.key,args.known_hosts)
    bundle=base_bundle(args.vendor)
    tv.ssh('test "$(id -u)" = 0 && test -x /usr/bin/node && test -x /usr/bin/curl && test -d /var/lib/webosbrew/init.d && test ! -e /var/lib/tvweb && test ! -e /var/lib/family-sync')
    # Refuse existing installations. No automatic removal or overwrite on failure.
    tv.ssh('umask 077; mkdir /var/lib/tvweb && tar -xf - -C /var/lib/tvweb',bundle,timeout=180)
    tv.ssh('chmod 700 /var/lib/tvweb/tvwebctl; cp /var/lib/tvweb/50-tvweb.sh /var/lib/webosbrew/init.d/50-tvweb; chmod 700 /var/lib/webosbrew/init.d/50-tvweb; /var/lib/tvweb/tvwebctl start')
    status=tv.ssh('/var/lib/tvweb/tvwebctl status')
    if not status.startswith('running'): raise RuntimeError('Base files installed but service not healthy; inspect TV logs before continuing')
    print('Pinned base installed with a unique local token and loopback-only HTTP. Continue with inspect and install. TV launcher tile setup remains in the local Glasshouse setup flow.')


def guided(kit_path):
    """Operator prepares credentials once; the family selects a TV and room."""
    kit_file=Path(kit_path).resolve();kit=read(kit_file)
    if kit.get('verifiedUpstream')!=UPSTREAM:
        raise ValueError('Ask your setup operator to verify this TV and prepare its setup kit first')
    def file(key):
        path=Path(kit[key]).expanduser()
        return str(path if path.is_absolute() else kit_file.parent/path)
    owner=file('ownerFile');key=file('keyFile');known=file('knownHostsFile')
    # Check cloud credentials before any TV writes.
    identity=api(read(owner),'/api/devices')
    print('Your household connection is ready. Connect this computer to the TV Wi-Fi.')
    host=input('TV IP address (from TV network settings): ').strip()
    tv=TV(host,key,known)
    state=tv.ssh('test "$(id -u)" = 0 && test -x /usr/bin/node && test -x /usr/bin/curl && test -d /var/lib/webosbrew/init.d && if test -e /var/lib/family-sync; then echo enrolled; elif test -x /var/lib/tvweb/tvwebctl; then echo base; elif test ! -e /var/lib/tvweb; then echo fresh; else echo incomplete; fi')
    if state not in ('fresh','base'):
        raise ValueError('This TV already has Family TV or an incomplete installation. Ask your operator to inspect it; nothing was changed.')
    label=input('Room name [Living room]: ').strip() or 'Living room'
    if len(label)>60:raise ValueError('Room name must be at most 60 characters')
    print('Selected TV: '+host+' | Room: '+label+' | Household: '+identity['household'])
    if input('Install on this TV? Type yes to continue: ').strip().lower()!='yes':
        print('Cancelled. No TV changes made.');return
    args=argparse.Namespace(host=host,key=key,known_hosts=known,vendor=str(ROOT/'vendor/glasshouse'))
    if state=='fresh':
        print('Installing the TV server...');install_base(args)
    tv.inspect()
    result=api(read(owner),'/api/enrollments',{'label':label})
    folder=kit_file.parent/('install-'+result['device'])
    enrollment=folder/'enrollment.json';job=folder/'job.json'
    save(enrollment,{**result,'server':read(owner)['server']})
    args.enrollment=str(enrollment);args.job=str(job);args.release=str(ROOT/'sites/family-tv/lib/tv-release.json');args.upstream_verified=UPSTREAM;args.resume=False
    print('Installing household controls...')
    try:provision(args)
    except Exception:
        print('Keep this recovery job file: '+str(job));raise
    print('Setup completed. Device: '+result['device'])
    print('Keep the TV on while your operator verifies a command. Then test a cold boot before handing over.')


class TV:
    def __init__(self, host, key, known):
        self.host = str(ipaddress.IPv4Address(host))
        if not any(ipaddress.ip_address(self.host) in ipaddress.ip_network(network) for network in ('10.0.0.0/8','172.16.0.0/12','192.168.0.0/16')):
            raise ValueError('Choose a private LAN television address')
        self.key, self.known = str(Path(key).resolve()), str(Path(known).resolve())
        if not Path(self.key).is_file() or not Path(self.known).is_file():
            raise ValueError('Provide an existing SSH key and verified known_hosts file')
        self.options = ['-i', self.key, '-o', 'UserKnownHostsFile=' + self.known,
                        '-o', 'StrictHostKeyChecking=yes', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=8']

    def ssh(self, command, data=None, timeout=90):
        result = subprocess.run(['ssh', *self.options, 'root@' + self.host, command], input=data,
                                capture_output=True, timeout=timeout)
        if result.returncode:
            raise RuntimeError('TV operation failed; verify SSH, supported base installation and available storage')
        return result.stdout.decode('utf-8', errors='replace').strip()

    def upload(self, path, data, mode='600'):
        # Paths are fixed implementation constants, never supplied by network input.
        self.ssh('umask 077; cat > ' + path + ' && chmod ' + mode + ' ' + path, data)

    def inspect(self):
        return self.ssh("test \"$(id -u)\" = 0 && test -x /usr/bin/node && test -x /usr/bin/curl && test -x /var/lib/tvweb/tvwebctl && test -d /var/lib/webosbrew/init.d && /var/lib/tvweb/tvwebctl status")


def provision(args):
    enrollment = read(args.job) if args.resume else read(args.enrollment)
    endpoint(enrollment['server'])
    if not args.resume and enrollment['expires'] <= time.time() * 1000:
        raise ValueError('Enrollment expired; create a fresh enrollment')
    bundle = release(args.release)
    tv = TV(args.host, args.key, args.known_hosts)
    tv.inspect()
    # A base Glasshouse install is required. Never take over an existing home.
    if not args.resume:
        tv.ssh('test ! -e /var/lib/family-sync && test ! -e /var/lib/tvweb/family-release')
    if args.upstream_verified != UPSTREAM:
        raise ValueError('Verify the installed base revision and pass --upstream-verified with the pinned commit')
    job = Path(args.job)
    token = enrollment['token'] if args.resume else secrets.token_hex(32)
    if not args.resume:
        save(job, {'server': enrollment['server'], 'token': token, 'device': enrollment['device'],
                   'household': enrollment['household'], 'host': tv.host})
    # Persist device token before the one-time exchange so a lost response does not lose credentials.
    claimed = api(enrollment, '/api/device/identity') if args.resume else api(enrollment, '/api/enroll/claim', {'deviceToken': token})
    if claimed['device']['id'] != enrollment['device'] or claimed['device']['household'] != enrollment['household']:
        raise RuntimeError('Unexpected enrollment identity; stop and revoke this enrollment')
    try:
        if args.resume:
            binding=tv.ssh('if test -d /var/lib/family-sync; then cat /var/lib/family-sync/device-id; else echo absent; fi')
            if binding not in ('absent',enrollment['device']):
                raise ValueError('TV belongs to another installation')
            tv.ssh('if test -x /var/lib/family-sync/tv-syncctl; then /var/lib/family-sync/tv-syncctl stop; fi; umask 077; mkdir -p /var/lib/family-sync')
        else:
            tv.ssh('umask 077; mkdir /var/lib/family-sync')
        tv.upload('/var/lib/family-sync/device-id', enrollment['device'].encode())
        tv.upload('/var/lib/family-sync/tv-sync.js', (ROOT / 'bridge/tv-sync.js').read_bytes())
        tv.upload('/var/lib/family-sync/tv-syncctl', (ROOT / 'bridge/tv-syncctl').read_bytes(), '700')
        tv.upload('/var/lib/family-sync/bootstrap.json', json.dumps(bundle, ensure_ascii=False).encode('utf-8'))
        # Bootstrap calls the same bounded installer and rollback path as normal TV updates.
        bootstrap = b"var m=require('/var/lib/family-sync/tv-sync');var s=new m.Sync();s.rollback().then(function(){return s.install(require('/var/lib/family-sync/bootstrap.json'));}).then(function(){if(s.state.blockedVersion)throw Error('Blocked');}).catch(function(){process.exitCode=1;});"
        tv.upload('/var/lib/family-sync/bootstrap.js', bootstrap)
        tv.ssh('/usr/bin/node /var/lib/family-sync/bootstrap.js', timeout=120)
        conf = 'url = ' + json.dumps(endpoint(enrollment['server']) + '/api/device/sync') + '\n'
        conf += 'header = ' + json.dumps('Authorization: Bearer ' + token) + '\n'
        conf += 'header = "Content-Type: application/json"\nproto = "=https"\n'
        tv.upload('/var/lib/family-sync/cloud.conf', conf.encode('utf-8'))
        tv.ssh('/usr/bin/node /var/lib/family-sync/tv-sync.js --once', timeout=120)
        tv.upload('/var/lib/webosbrew/init.d/55-family-sync', (ROOT / 'bridge/55-family-sync').read_bytes(), '700')
        tv.ssh('/var/lib/family-sync/tv-syncctl start; /var/lib/family-sync/tv-syncctl status')
        print('Installed and completed one authenticated sync. Check owner device status and cold-boot recovery.')
    except Exception:
        raise RuntimeError('Install interrupted. Job credentials retained locally. Use install --resume for this same job, or recover to restore a pending update and owner revoke before abandoning it.') from None


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    check=commands.add_parser('preflight',help='Read-only TCP reachability check; no credentials or TV changes')
    check.add_argument('--host',required=True)
    guide=commands.add_parser('guided',help='Guided setup using an operator-prepared private kit')
    guide.add_argument('--kit',required=True)
    kit=commands.add_parser('make-kit',help='Prepare local file references for guided setup; does not copy secrets')
    for option in ('owner','key','known-hosts','out'):kit.add_argument('--'+option,required=True)
    kit.add_argument('--upstream-verified',required=True)
    scan=commands.add_parser('discover',help='List untrusted SSDP candidates on a selected local interface')
    scan.add_argument('--interface',required=True,help='This computer Wi-Fi IPv4 address, not the TV address')
    create = commands.add_parser('create-household', help='Generate isolated owner credentials and provisioning SQL locally')
    create.add_argument('--name', required=True); create.add_argument('--server', required=True); create.add_argument('--out', required=True)
    for action in ['devices', 'enroll', 'command', 'revoke', 'status']:
        sub = commands.add_parser(action); sub.add_argument('--owner', required=True)
        if action == 'enroll':
            sub.add_argument('--label', required=True); sub.add_argument('--out', required=True)
        if action in ('command', 'revoke', 'status'): sub.add_argument('--device', required=True)
        if action == 'command': sub.add_argument('--json', required=True, help='Path to command JSON, not inline secrets')
    for action in ['inspect', 'install', 'recover', 'install-base']:
        sub = commands.add_parser(action)
        sub.add_argument('--host', required=True); sub.add_argument('--key', required=True); sub.add_argument('--known-hosts', required=True)
        if action=='install-base': sub.add_argument('--vendor',default=str(ROOT/'vendor/glasshouse'))
        if action == 'install':
            sub.add_argument('--enrollment'); sub.add_argument('--job', required=True)
            sub.add_argument('--resume',action='store_true')
            sub.add_argument('--release', default=str(ROOT / 'sites/family-tv/lib/tv-release.json'))
            sub.add_argument('--upstream-verified', required=True)
    args = parser.parse_args(argv)
    if args.command == 'preflight':print(json.dumps(preflight(args.host),indent=2))
    elif args.command == 'guided':guided(args.kit)
    elif args.command == 'make-kit':
        if args.upstream_verified!=UPSTREAM:raise ValueError('Verify compatibility with the pinned base first')
        for path in (args.owner,args.key,args.known_hosts):
            if not Path(path).is_file():raise ValueError('A referenced credential file does not exist')
        save(args.out,{'ownerFile':str(Path(args.owner).resolve()),'keyFile':str(Path(args.key).resolve()),'knownHostsFile':str(Path(args.known_hosts).resolve()),'verifiedUpstream':UPSTREAM})
        print('Local setup kit saved. Keep the referenced credentials private; do not publish this file.')
    elif args.command == 'discover': print(json.dumps(discover(args.interface),indent=2))
    elif args.command == 'create-household':
        folder = Path(args.out)
        if folder.exists(): raise ValueError('Choose a new directory for each household')
        folder.mkdir(parents=True)
        h, token = str(uuid.uuid4()), secrets.token_hex(32)
        save(folder / 'owner.json', {'server': endpoint(args.server), 'household': h, 'token': token})
        name = args.name.replace("'", "''")
        sql = "BEGIN TRANSACTION;\nINSERT INTO households VALUES('%s','%s',%d);\nINSERT INTO owners(token_hash,household) VALUES('%s','%s');\nCOMMIT;\n" % (h, name, time.time()*1000, hashlib.sha256(token.encode()).hexdigest(), h)
        (folder / 'provision.sql').write_text(sql, encoding='utf-8')
        print('Created owner.json and provision.sql. Apply SQL only to the new household service database.')
    elif args.command == 'inspect':
        print(TV(args.host,args.key,args.known_hosts).inspect())
    elif args.command == 'install-base': install_base(args)
    elif args.command == 'install':
        if not args.resume and not args.enrollment: parser.error('install requires --enrollment or --resume')
        provision(args)
    elif args.command == 'recover':
        tv=TV(args.host,args.key,args.known_hosts)
        tv.ssh('/var/lib/family-sync/tv-syncctl stop')
        tv.ssh('/usr/bin/node -e "new (require(\'/var/lib/family-sync/tv-sync\').Sync)().rollback().catch(function(){process.exitCode=1;})"', timeout=120)
        print('Pending update rollback completed; sync stopped. Revoke abandoned enrollment using the owner credential.')
    else:
        config = read(args.owner)
        if args.command == 'devices':
            response = api(config,'/api/devices')
            # Avoid dumping viewing records and PIN-bearing snapshots into terminal/chat logs.
            print(json.dumps({'household': response['household'], 'devices': [{k:d.get(k) for k in ('id','label','revoked','received')} for d in response['devices']]}, indent=2))
        elif args.command == 'enroll':
            if Path(args.out).exists(): raise ValueError('Enrollment output already exists')
            result = api(config,'/api/enrollments',{'label':args.label})
            save(args.out, {**result,'server':config['server']}); print('Enrollment saved; expires in 10 minutes.')
        elif args.command == 'revoke':
            print(json.dumps(api(config,'/api/devices/'+str(uuid.UUID(args.device))+'/revoke',{})))
        elif args.command == 'status':
            print(json.dumps(api(config,'/api/devices/'+str(uuid.UUID(args.device))+'/commands'),indent=2))
        else:
            command = read(args.json); command.setdefault('requestId',str(uuid.uuid4()))
            print(json.dumps(api(config,'/api/devices/'+str(uuid.UUID(args.device))+'/commands',command)))


if __name__ == '__main__':
    try: main()
    except (ValueError, RuntimeError, OSError, subprocess.SubprocessError) as exc:
        print(str(exc), file=sys.stderr); sys.exit(1)

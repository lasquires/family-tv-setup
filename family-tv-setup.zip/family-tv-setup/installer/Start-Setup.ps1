$ErrorActionPreference = 'Stop'
$project = Split-Path -Parent $PSScriptRoot
Set-Location -LiteralPath $project
$runtime = Join-Path $project 'runtime'
$python = Join-Path $runtime 'python.exe'
if (-not (Test-Path -LiteralPath $python)) {
    Write-Host 'Preparing Family TV. Downloading the official portable Python runtime…'
    $archive = Join-Path $project 'python-runtime.zip'
    Invoke-WebRequest 'https://www.python.org/ftp/python/3.13.7/python-3.13.7-embed-amd64.zip' -OutFile $archive
    if ((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash -ne 'F6CCA216A359BE84797CABB54149CE5E062AFB16CC7567EB7FC51CACB2D86B65') {
        throw 'The runtime download failed its integrity check. Please download setup again.'
    }
    Expand-Archive -LiteralPath $archive -DestinationPath $runtime -Force
    Set-Content -LiteralPath (Join-Path $runtime 'python313._pth') -Value "python313.zip`n.`n../installer`n.." -Encoding ascii
}
Write-Host 'Opening your Family TV wizard. Keep this window open until setup finishes.'
& $python (Join-Path $PSScriptRoot 'factory.py')
if ($LASTEXITCODE -ne 0) { Read-Host 'Setup stopped. Press Enter to close' }

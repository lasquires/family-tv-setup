$ErrorActionPreference = 'Stop'
$project = Split-Path -Parent $PSScriptRoot
Set-Location -LiteralPath $project
Write-Host 'Family TV guided setup'
Write-Host 'Your setup operator supplies a private setup-kit.json file for this home.'
$kitFile = Read-Host 'Drag the setup-kit.json file here, or enter its full path'
$kitFile = $kitFile.Trim().Trim('"').Trim("'")
if (-not (Test-Path -LiteralPath $kitFile -PathType Leaf)) { throw 'Setup kit not found.' }
if (Get-Command py -ErrorAction SilentlyContinue) {
    & py -3 installer/setup.py guided --kit $kitFile
} else {
    Write-Host 'Python 3 is required. Install it from python.org, then reopen setup.'
    exit 1
}
if ($LASTEXITCODE -ne 0) { Write-Host 'Setup needs attention. Keep the message above for your setup operator.' }
Read-Host 'Press Enter to close'

// Injected into the household-specific plugin closure by the installer.
// Credentials are generated per TV and are never included in the public package.
var familyCloudConfig=FAMILY_CLOUD_CONFIG;
var familyCloudTimer=null,familyCloudBusy=false;
var familyCloudFile='/opt/usr/home/owner/share/family-tv-cloud-state.json';
var familyCloudState={results:[],completed:{}};
try{familyCloudState=JSON.parse(fs.readFileSync(familyCloudFile,'utf8'));}catch(e){if(e.code!=='ENOENT')throw e;}
if(familyCloudState.pending){familyCloudState.results.push({id:familyCloudState.pending,status:'uncertain'});delete familyCloudState.pending;}
function familyCloudSave(){fs.writeFileSync(familyCloudFile+'.tmp',JSON.stringify(familyCloudState),{mode:384});fs.renameSync(familyCloudFile+'.tmp',familyCloudFile);}
function familyCloudRequest(body){return new Promise(function(resolve,reject){
 var u=new (require('url').URL)(familyCloudConfig.server+'/api/device/sync');
 var req=require('https').request(u,{method:'POST',headers:{Authorization:'Bearer '+familyCloudConfig.token,'Content-Type':'application/json','User-Agent':'FamilyTV-TV/1.0'}},function(res){
  var raw='';res.on('data',function(c){raw+=c;if(raw.length>200000)req.destroy(Error('Response too large'));});res.on('end',function(){try{if(res.statusCode!==200)throw Error('Sync rejected');resolve(JSON.parse(raw));}catch(e){reject(e);}});
 });req.setTimeout(20000,function(){req.destroy(Error('Sync timeout'));});req.on('error',reject);req.end(JSON.stringify(body));
});}
function familyCloudCycle(){
 if(familyCloudBusy||!running)return;familyCloudBusy=true;
 var snap=snapshot();snap.online=snap.ok;snap.model=familyCloudConfig.model;snap.observedAt=Date.now();
 familyCloudRequest({snapshot:snap,results:familyCloudState.results}).then(function(response){
  familyCloudState.results=[];familyCloudSave();
  return (response.commands||[]).reduce(function(chain,c){return chain.then(function(){
   if(!/^[a-f0-9-]{36}$/.test(c.commandId||''))return;
   if(familyCloudState.completed[c.commandId]){familyCloudState.results.push({id:c.commandId,status:familyCloudState.completed[c.commandId]});return;}
   familyCloudState.pending=c.commandId;familyCloudSave();
   return enqueue(function(){return command(c);}).then(function(){return 'confirmed';},function(){return 'failed';}).then(function(status){
    familyCloudState.completed[c.commandId]=status;familyCloudState.results.push({id:c.commandId,status:status});delete familyCloudState.pending;
    var ids=Object.keys(familyCloudState.completed);while(ids.length>200)delete familyCloudState.completed[ids.shift()];familyCloudSave();
   });
  });},Promise.resolve());
 }).catch(function(){}).then(function(){familyCloudBusy=false;});
}

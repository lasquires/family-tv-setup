'use strict';
// Runs outside Glasshouse so an application update cannot kill its own updater.
// Node 8 compatible; curl supplies the TV's validated system TLS transport.
const fs=require('fs'),http=require('http'),cp=require('child_process'),crypto=require('crypto');
const ROOT='/var/lib/family-sync',APP='/var/lib/tvweb';
const ALLOWED=['lib/family.js','assets/family.html','lib/profiles.js','assets/profile-picker.js','lib/routes.js','assets/home.html'];
const PROFILE=['profile','saveProfile','sharedApps','passcodes','guestCode','deleteProfile','grant','revoke','protectApps','protectApp','pausePins','routine','sleepTimer','appearance'];
function read(file,fallback){try{return JSON.parse(fs.readFileSync(file,'utf8'));}catch(e){if(e.code==='ENOENT')return fallback;throw e;}}
function write(file,data){fs.writeFileSync(file+'.tmp',JSON.stringify(data),{mode:384});fs.renameSync(file+'.tmp',file);}
function delay(ms){return new Promise(r=>setTimeout(r,ms));}
function run(file,args){return new Promise((resolve,reject)=>cp.execFile(file,args,{timeout:60000,maxBuffer:4000000},(e,out)=>e?reject(new Error('Local process failed')):resolve(out)));}
function validRelease(r){
 if(!r||!/^\w{16}$/.test(r.version)||!/^[a-f0-9]+$/.test(r.version)||r.upstream!=='0a110e74a0c1256134a4ff93f351919023306d07'||!Array.isArray(r.files)||r.files.length!==ALLOWED.length)throw Error('Invalid release');
 const seen={};r.files.forEach(f=>{if(ALLOWED.indexOf(f.path)<0||seen[f.path]||typeof f.content!=='string'||Buffer.byteLength(f.content)>1500000||crypto.createHash('sha256').update(f.content).digest('hex')!==f.sha256)throw Error('Invalid release file');seen[f.path]=true;});return r;
}
function removable(a){return a.removable&&!/^(com\.tvweb\.|com\.webos\.|com\.palm\.|org\.webosbrew\.)/.test(a.id)&&!/airplay|miracast|castservice/i.test(a.id);}
class Sync {
 constructor(root,app){this.root=root||ROOT;this.app=app||APP;this.state=read(this.root+'/state.json',{results:[],completed:{}});this.state.results=this.state.results||[];this.state.completed=this.state.completed||{};this.cache={};this.lastInventory=0;this.lastHistory=0;this.lastPersist='';this.run=run;this.delay=delay;}
 persist(){const data=JSON.stringify(this.state);if(data!==this.lastPersist){write(this.root+'/state.json',this.state);this.lastPersist=data;}}
 local(path,data){return new Promise((resolve,reject)=>{const config=read(this.app+'/config.json',{}),body=data===undefined?null:JSON.stringify(data);const req=http.request({hostname:'127.0.0.1',port:8080,path,method:body?'POST':'GET',headers:{Authorization:'Bearer '+config.token,'Content-Type':'application/json'}},res=>{let out='';res.on('data',b=>{out+=b;if(out.length>2000000)req.destroy(Error('Response too large'));});res.on('end',()=>{try{if(res.statusCode!==200)throw Error('TV request failed');resolve(JSON.parse(out));}catch(e){reject(e);}});});req.setTimeout(8000,()=>req.destroy(Error('TV timeout')));req.on('error',reject);req.end(body);});}
 cloud(body){return new Promise((resolve,reject)=>{const child=cp.execFile('/usr/bin/curl',['--config',this.root+'/cloud.conf','--silent','--show-error','--fail','--connect-timeout','8','--max-time','20','--max-filesize','4000000','--data-binary','@-'],{timeout:25000,maxBuffer:4000000},(e,out)=>{try{if(e)throw Error('Site unavailable');const data=JSON.parse(out);if(!data.ok)throw Error('Site rejected report');resolve(data);}catch(err){reject(err);}});child.stdin.on('error',()=>{});child.stdin.end(JSON.stringify(body));});}
 async snapshot(){
  const family=await this.local('/api/family');if(!family.ok)throw Error('TV service unavailable');
  const profiles=await this.local('/api/family/profiles');const now=Date.now();
  try{const home=await this.local('/api/family/home-settings');this.cache.homeSettings=home.changes;this.cache.capabilities=Object.assign({},this.cache.capabilities,{homeSettings:true});}catch(e){this.cache.homeSettings={};this.cache.capabilities=Object.assign({},this.cache.capabilities,{homeSettings:false});}
  if(now-this.lastHistory>30000){this.cache.history=await this.local('/api/history?days=7');this.lastHistory=now;}
  if(now-this.lastInventory>300000){this.cache.catalogue=await this.local('/api/home/catalogue');this.cache.installedApps=(await this.local('/api/apps')).installed.filter(removable).map(a=>({id:a.id,title:a.title||a.id,removable:true}));this.lastInventory=now;}
  let version=null;try{version=fs.readFileSync(this.app+'/family-release','utf8').trim();}catch(e){}
  return Object.assign({},this.cache,{online:true,family,profiles,installedVersion:version,updateStatus:this.state.updateStatus||'Direct TV sync active',homeSetupStatus:this.state.homeSetupStatus||null,observedAt:now,transport:'tv-direct',syncVersion:1,appsObservedAt:this.lastInventory/1000});
 }
 async command(cmd){
  const id=cmd.commandId;if(this.state.completed[id])return this.state.completed[id];
  const action=cmd.action;let result;
  try{
   if(action==='uninstallApp'){
    const installed=(await this.local('/api/apps')).installed;const app=installed.find(a=>a.id===cmd.app);
    if(!app){result={ok:true};}else if(!removable(app)){result={ok:false};}else{result=await this.local('/api/apps/uninstall',{id:cmd.app});result.ok=!!result.ok&&!(await this.local('/api/apps')).installed.some(a=>a.id===cmd.app);}
    this.lastInventory=0;
   }else if(action==='homeLayout'){const body=Object.assign({},cmd);delete body.commandId;result=await this.local('/api/family/home-settings',body);this.lastInventory=0;}
   else if(action==='refresh'){this.lastInventory=0;this.lastHistory=0;result={ok:true};}
   else if(PROFILE.indexOf(action)>=0||['lock','pin','enabled'].indexOf(action)>=0){const body=Object.assign({},cmd);delete body.commandId;result=await this.local(PROFILE.indexOf(action)>=0?'/api/family/profiles':'/api/family',body);}
   else result={ok:false};
   result={id,status:result.ok?'confirmed':'failed',message:result.ok?'TV confirmed the change.':'TV did not confirm this change.'};
  }catch(e){result={id,status:'uncertain',message:'No confirmation. Refresh before retrying.'};}
  if(result.status!=='uncertain'){this.state.completed[id]=result;const ids=Object.keys(this.state.completed);while(ids.length>100)delete this.state.completed[ids.shift()];}
  this.state.results.push(result);this.persist();return result;
 }
 async install(release){
  if(!release||release.version===this.state.blockedVersion)return;
  let installed='';try{installed=fs.readFileSync(this.app+'/family-release','utf8').trim();}catch(e){}
  if(installed===release.version)return;validRelease(release);
  // Parse with the TV's own Node before stopping its working server.
  this.state.updatePhase='Checking downloaded files';this.persist();
  try{for(const f of release.files){if(/\.js$/.test(f.path)){const check=this.root+'/release-check.js';fs.writeFileSync(check,f.content);try{await this.run('/usr/bin/node',['--check',check]);}finally{if(fs.existsSync(check))fs.unlinkSync(check);}}}}catch(e){this.state.blockedVersion=release.version;this.state.updateStatus='Update rejected: JavaScript is not compatible with this TV. The running app was kept.';this.persist();throw e;}
  const backup=this.root+'/rollback';if(!fs.existsSync(backup))fs.mkdirSync(backup,448);
  release.files.forEach(f=>{const name=f.path.replace(/\//g,'__');const exists=fs.existsSync(this.app+'/'+f.path);fs.writeFileSync(backup+'/'+name,exists?fs.readFileSync(this.app+'/'+f.path):Buffer.alloc(0));fs.writeFileSync(backup+'/'+name+'.present',exists?'1':'0');fs.writeFileSync(this.app+'/'+f.path+'.new',f.content);});
  this.state.previousVersion=installed;this.state.installing=release.version;this.persist();
  try{
   this.state.updatePhase='Starting the updated TV server';this.persist();
   await this.run(this.app+'/tvwebctl',['stop']);release.files.forEach(f=>fs.renameSync(this.app+'/'+f.path+'.new',this.app+'/'+f.path));await this.run(this.app+'/tvwebctl',['start']);
   this.state.updatePhase='Checking the updated TV server';this.persist();
   let healthy=false;for(let n=0;n<12;n++){await this.delay(2000);try{if((await this.local('/api/family')).ok&&(await this.local('/api/family/profiles')).ok){healthy=true;break;}}catch(e){}}
   if(!healthy)throw Error('Health check failed');fs.writeFileSync(this.app+'/family-release',release.version);this.state.updateStatus='Installed and health-checked on TV';this.state.blockedVersion=null;delete this.state.installing;this.persist();
   // Only the fixed agent bundled in the healthy app release can replace us.
   // The service responds before restarting this process; no install is pending.
   try{await this.local('/api/family/home-settings',{action:'updateSync'});}catch(e){}
  }catch(e){this.state.updateFailure=this.state.updatePhase;await this.rollback();throw e;}
 }
 async rollback(){
  if(!this.state.installing)return;
  await this.run(this.app+'/tvwebctl',['stop']);const backup=this.root+'/rollback';
  ALLOWED.forEach(path=>{const name=path.replace(/\//g,'__');if(fs.readFileSync(backup+'/'+name+'.present','utf8')==='1')fs.writeFileSync(this.app+'/'+path,fs.readFileSync(backup+'/'+name));else if(fs.existsSync(this.app+'/'+path))fs.unlinkSync(this.app+'/'+path);});
  fs.writeFileSync(this.app+'/family-release',this.state.previousVersion||'');
  await this.run(this.app+'/tvwebctl',['start']);this.state.blockedVersion=this.state.installing;delete this.state.installing;this.state.updateStatus='Update failed during '+(this.state.updateFailure||'installation')+'; previous files restored';this.persist();
 }
 async configureHome(preset){
  const marker=this.root+'/home-configured.json';
  if(fs.existsSync(marker))return;
  if(!preset||!preset.layout||typeof preset.layout!=='object')throw Error('Missing standard home preset');
  const before=await this.local('/api/home');
  // An already enabled custom home belongs to the family; never reset it.
  if(before.enabled&&before.active){write(marker,{enabled:true,active:true,preserved:true});return;}
  this.state.homeSetupStatus='Activating the standard home screen';this.persist();
  if(!before.enabled){
   if(!(await this.local('/api/home/layout',preset.layout)).ok)throw Error('Home layout rejected');
   if(preset.wallpapers){
    if(!(await this.local('/api/home/wallpapers',preset.wallpapers)).ok)throw Error('Home wallpaper sources rejected');
    if(preset.wallpapers.choose&&!(await this.local('/api/home/wallpapers',{choose:preset.wallpapers.choose})).ok)throw Error('Home wallpaper selection rejected');
   }
   try{if(!(await this.local('/api/home/enable',{})).ok)throw Error('Home enable rejected');}catch(e){await this.delay(2000);if(!(await this.local('/api/home')).enabled)throw e;}
  }
  if(!(await this.local('/api/control',{action:'launch_app',value:'com.tvweb.home'})).ok)throw Error('Home launch rejected');
  for(let n=0;n<10;n++){const s=await this.local('/api/home');if(s.enabled&&s.active){write(marker,{enabled:true,active:true});this.state.homeSetupStatus='Standard home screen enabled and verified';this.persist();return;}await this.delay(1000);}
  throw Error('Home screen activation was not confirmed');
 }
 async cycle(){
  const snapshot=await this.snapshot();const response=await this.cloud({snapshot,results:this.state.results});
  if(this.state.results.length){this.state.results=[];this.persist();}
  // Execute dispatched commands before an update, which may briefly restart Glasshouse.
  for(const command of response.commands||[])await this.command(command);
  if(this.state.results.length){await this.cloud({snapshot:await this.snapshot(),results:this.state.results,ackOnly:true});this.state.results=[];this.persist();}
  await this.install(response.release);
  if(response.homeSetup&&Date.now()>(this.state.nextHomeAttempt||0)){try{await this.configureHome(response.homeSetup);}catch(e){this.state.homeSetupStatus='Home setup needs attention: '+e.message;this.state.nextHomeAttempt=Date.now()+300000;this.persist();}}
 }
}
async function main(){
 const sync=new Sync();await sync.rollback();let failures=0;
 while(true){try{await sync.cycle();if(failures)console.log(new Date().toISOString(),'Sync recovered');failures=0;}catch(e){failures++;if(failures===1||failures%30===0)console.log(new Date().toISOString(),'Sync waiting for network or TV service');}
  if(process.argv.indexOf('--once')>=0){if(failures)process.exitCode=1;return;}
  await delay(failures?Math.min(30000,5000*failures):5000);
 }
}
module.exports={Sync,validRelease,removable};
if(require.main===module)main().catch(()=>{console.error('Sync service needs attention');process.exitCode=1;});
